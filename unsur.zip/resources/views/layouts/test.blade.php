//mts
public function mtsGet()
{
    $mtss = mts::all();
    return view('lembaga-pendidikan.mts.index', ['mtss' => $mtss]);
}

public function mtsCreate()
{
  return view('lembaga-pendidikan/mts/create');
}

public function mtsDetail($id)
{
  $mts = mts::find($id);
  return view('lembaga-pendidikan.mts.detail', compact('mts'));
}

public function mtsEdit($id)
{
  $mts = mts::find($id);
  return view('lembaga-pendidikan.mts.edit', compact('mts'));
}

public function mtsPost(Request $req)
{
    $id = $req->get('id');
    if($id){
        $mts = mts::find($id);
    }else{
        $mts = new mts;
    }
    if($req->gambar){
      if($req->hasFile('gambar')){
        $foto = $req->file('gambar');
        $filename = time() . '.' . $foto->getClientOriginalExtension();
        $destinationPath = 'imtsge/';              
         $foto->move($destinationPath, $filename);
        }
        $mts->gambar = $filename;
    }

    $mts->judul = $req->judul;
    $mts->isi = $req->isi;
    $mts->save();
    return redirect()->route('lembaga-pendidikan.mts.index')->with(['success' => 'Data Berhasil Di Simpan']);
}

public function mtsDel($id) {
  $mts = mts::find($id);
  $mts->delete();

  if($mts){
    return response()->json([
        'status' => 'success'
    ]);
}else{
    return response()->json([
        'status' => 'error'
    ]);
}
}