<?php $__env->startSection('content'); ?>
<div class="main-content">
    <section class="section">
        <div class="section-header">
            <h1>Detail Visi Misi</h1>
        </div>
        <div class="section-body">
            <div class="card">
                <div class="card-header">
                    <h4><i class="fas fa-universal-access"></i> Detail Visi Misi</h4>
                </div>
                <div class="card-body">
                    <p>Visi</p>
                    <p><?php echo $visi->visi; ?></p>
                    Misi
                    <p><?php echo $visi->misi; ?></p>
                    TUJUAN
                    <p><?php echo $visi->tujuan; ?></p>
                </div>
            </div>
        </div>
</div>
    </section>
</div>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\unsur\resources\views/profil/visi-misi/detail.blade.php ENDPATH**/ ?>