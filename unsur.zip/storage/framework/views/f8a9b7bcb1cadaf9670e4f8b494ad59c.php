

<?php $__env->startSection('content'); ?>
<div class="main-content">
    <section class="section">
        <div class="section-header">
            <h1>Detail Kontak yayasan</h1>
        </div>
        <div class="section-body">
          
            <div class="card">
                <div class="card-header">
                    <h4><i class="fas fa-chalkboard-teacher"></i> Detail Kontak yayasan</h4>
                </div>
                <div class="card-body">
                    <center>
                    <iframe src="<?php echo e($kontak->maps); ?>" width="250" height="250" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
                    </center>
                    <p><?php echo $kontak->telp; ?></p>
                    <p><?php echo $kontak->fax; ?></p>
                    <p><?php echo $kontak->email; ?></p>
                </div>
            </div>
        </div>
</div>
    </section>
</div>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\unsur\resources\views/kontak/kontak-yayasan/detail.blade.php ENDPATH**/ ?>