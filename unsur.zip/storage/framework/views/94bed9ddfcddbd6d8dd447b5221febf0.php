<?php $__env->startSection('content'); ?>
<div class="main-content">
    <section class="section">
        <div class="section-header">
            <h1>Detail Sarana dan Perasarana</h1>
        </div>
        <div class="section-body">
        
            <div class="card">
                <div class="card-header">
                    <h4><i class="fas fa-history"></i> Detail Sarana dan Perasarana</h4>
                </div>
                <body>
            <table>
        <tr>
              <th scope="col" style="text-align: center;width: 6%">NO.</th>
            <th>URAIAN</th>
            <th>JUMLAH YANG ADA</th>
            <th>KONDISI</th>
            <th>JUMLAH YANG DI PERLUKAN</th>
            <th>KETERANGAN</th>
            </tr>
        <?php $nomor = 1; ?>
        <tr>
            
        <td scope="row" style="text-align: center"><?php echo e($nomor++); ?></td>   
        <td><?php echo e($sarana->uraian); ?></td>
        <td><?php echo e($sarana->jumlah_ada); ?></td>
        <td><?php echo e($sarana->kondisi); ?></td>
        <td><?php echo e($sarana->jumlah_yg_diperlukan); ?></td>
        <td><?php echo $sarana->keterangan; ?></td>
        </tr>
        
    </table>
            </div>
        </div>
</div>
    </section>
</div>
<style>
        table {
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 10px;
        }
        th {
            background-color: #32a5fc;
            color: white;
        }
    </style>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\unsur\resources\views/profil/sarana/detail.blade.php ENDPATH**/ ?>