    <!-- Overlay -->
    <div class="loader-page overlay-panel overlay-background overlay-fade text-center vertical-align">
      <div class="loader vertical-align-middle loader-cube"></div>
    </div>
    <!-- Footer -->
    <footer class="site-footer">
      <div class="site-footer-legal">&copy; 2023</div>
      <div class="site-footer-right"></div>
    </footer>
    <script>
      var APP_URL = '<?php echo e(url("")); ?>';
    </script>
    <!-- Core  -->
    <script src="<?php echo e(asset('global/plugins/babel-external-helpers/babel-external-helpers.js')); ?>"></script>
    <script src="<?php echo e(asset('global/plugins/jquery/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('global/plugins/popper-js/umd/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('global/plugins/bootstrap/bootstrap.js')); ?>"></script>
    <script src="<?php echo e(asset('global/plugins/animsition/animsition.js')); ?>"></script>
    <script src="<?php echo e(asset('global/plugins/mousewheel/jquery.mousewheel.js')); ?>"></script>
    <script src="<?php echo e(asset('global/plugins/asscrollbar/jquery-asScrollbar.js')); ?>"></script>
    <script src="<?php echo e(asset('global/plugins/asscrollable/jquery-asScrollable.js')); ?>"></script>
    <script src="<?php echo e(asset('global/plugins/ashoverscroll/jquery-asHoverScroll.js')); ?>"></script>
    <script src="<?php echo e(asset('global/plugins/waves/waves.js')); ?>"></script>

    <!-- Plugins -->
    <script src="<?php echo e(asset('global/plugins/switchery/switchery.js')); ?>"></script>
    <script src="<?php echo e(asset('global/plugins/intro-js/intro.js')); ?>"></script>
    <script src="<?php echo e(asset('global/plugins/screenfull/screenfull.js')); ?>"></script>
    <script src="<?php echo e(asset('global/plugins/slidepanel/jquery-slidePanel.js')); ?>"></script>
    <script src="<?php echo e(asset('global/plugins/sweetalert2/sweetalert2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('global/plugins/jquery-dateformat/jquery-dateformat.min.js')); ?>"></script>
    <script src="<?php echo e(asset('global/plugins/bootstrap-datepicker/bootstrap-datepicker.js')); ?>"></script>
    <script src="<?php echo e(asset('global/plugins/summernote/summernote.min.js')); ?>"></script>
    <script src="<?php echo e(asset('global/plugins/select2/select2.min.js')); ?>"></script>

    <!-- DataTable -->
    <script src="<?php echo e(asset('global/plugins/datatables.net/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('global/plugins/datatables.net-bs4/dataTables.bootstrap4.js')); ?>"></script>
    <script src="<?php echo e(asset('global/plugins/datatables.net-fixedheader/dataTables.fixedHeader.js')); ?>"></script>
    <script src="<?php echo e(asset('global/plugins/datatables.net-fixedcolumns/dataTables.fixedColumns.js')); ?>"></script>
    <script src="<?php echo e(asset('global/plugins/datatables.net-rowgroup/dataTables.rowGroup.js')); ?>"></script>
    <script src="<?php echo e(asset('global/plugins/datatables.net-scroller/dataTables.scroller.js')); ?>"></script>
    <script src="<?php echo e(asset('global/plugins/datatables.net-responsive/dataTables.responsive.js')); ?>"></script>
    <script src="<?php echo e(asset('global/plugins/datatables.net-responsive-bs4/responsive.bootstrap4.js')); ?>"></script>
    <script src="<?php echo e(asset('global/plugins/datatables.net-buttons/dataTables.buttons.js')); ?>"></script>
    <script src="<?php echo e(asset('global/plugins/datatables.net-buttons/buttons.html5.js')); ?>"></script>
    <script src="<?php echo e(asset('global/plugins/datatables.net-buttons/buttons.flash.js')); ?>"></script>
    <script src="<?php echo e(asset('global/plugins/datatables.net-buttons/buttons.print.js')); ?>"></script>
    <script src="<?php echo e(asset('global/plugins/datatables.net-buttons/buttons.colVis.js')); ?>"></script>
    <script src="<?php echo e(asset('global/plugins/datatables.net-buttons-bs4/buttons.bootstrap4.js')); ?>"></script>

    <!-- Scripts -->
    <script src="<?php echo e(asset('global/js/Component.js')); ?>"></script>
    <script src="<?php echo e(asset('global/js/Plugin.js')); ?>"></script>
    <script src="<?php echo e(asset('global/js/Base.js')); ?>"></script>
    <script src="<?php echo e(asset('global/js/Config.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/js/Section/Menubar.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/Section/GridMenu.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/Section/Sidebar.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/Section/PageAside.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/Plugin/menu.js')); ?>"></script>

    <!-- Config -->
    <script src="<?php echo e(asset('global/js/config/colors.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/config/tour.js')); ?>"></script>

    <!-- Page -->
    <script src="<?php echo e(asset('assets/js/Site.js')); ?>"></script>
    <!-- Hide Sementara -->
    <!--script src="<?php echo e(asset('global/js/Plugin/asscrollable.js')); ?>"></script>
    <script src="<?php echo e(asset('global/js/Plugin/slidepanel.js')); ?>"></script>
    <script src="<?php echo e(asset('global/js/Plugin/switchery.js')); ?>"></script-->
    <script src="<?php echo e(asset('assets/js/remark.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>

    
    <?php echo $__env->yieldContent('page_js'); ?>
    </body>

    </html><?php /**PATH C:\xampp\htdocs\unsur\resources\views/common/footer.blade.php ENDPATH**/ ?>