<?php $__env->startSection('content'); ?>
<div class="main-content">
    <section class="section">
        <div class="section-header">
            <h1>Detail Vidio</h1>
        </div>
        <div class="section-body">
            
            <div class="card">
                <div class="card-header">
                    <h4><i class="far fa-address-card"></i> Detail Vidio</h4>
                </div>
                <div class="card-body">
                    <h5 class="text-center"><?php echo e($vidio->judul); ?></h5>
                    <center>
                        <video width="320" height="240" controls>
                            <source src="<?php echo e(asset('/image/'.$vidio->video)); ?>" type="video/mp4">
                        </video>
                    </center>
                    <p><?php echo $vidio->isi; ?></p>
                </div>
            </div>
        </div>
</div>
    </section>
</div>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\unsur\resources\views/profil/vidio/detail.blade.php ENDPATH**/ ?>