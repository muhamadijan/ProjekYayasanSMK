<?php
$idGrup = Auth::user()->grup_id;
?>
<div class="site-menubar">
  <div class="site-menubar-body">
    <div>
      <div>
        <ul class="site-menu" data-plugin="menu">
          <li class="site-menu-category">Menu</li>
          <li class="site-menu-item">
            <a class="animsition-link" href="<?php echo e(url('/dashboard')); ?>">
              <i class="site-menu-icon md-view-dashboard" aria-hidden="true"></i>
              <span class="site-menu-title">Dashboard</span>
            </a>
          </li>
          <?php if($idGrup == 1): ?>
          <li class="site-menu-item has-sub <?php echo e(in_array($linkActive, ['instansi', 'pengaturan-bidang', 'pengaturan-program', 'pengaturan-kompetensi', 'kelas', 'personal', 'siswa', 'tapel']) ? 'active open' : ''); ?>">
            <a href="javascript:void(0)">
              <i class="site-menu-icon md-view-list" aria-hidden="true"></i>
              <span class="site-menu-title">Data Master</span>
              <span class="site-menu-arrow"></span>
            </a>
            <ul class="site-menu-sub">
              <li class="site-menu-item <?php echo e(in_array($linkActive, ['instansi']) ? 'active' : ''); ?>">
                <a class="animsition-link" href="<?php echo e(url('data/instansi')); ?>">
                  <span class="site-menu-title">Instansi</span>
                </a>
              </li>
              <li class="site-menu-item <?php echo e(in_array($linkActive, ['tapel']) ? 'active' : ''); ?>">
                <a class="animsition-link" href="<?php echo e(url('data/tapel')); ?>">
                  <span class="site-menu-title">Tahun Pelajaran</span>
                </a>
              </li>
              <li class="site-menu-item <?php echo e(in_array($linkActive, ['pengaturan-bidang']) ? 'active' : ''); ?>">
                <a class="animsition-link" href="<?php echo e(url('pengaturan-bidang')); ?>">
                  <span class="site-menu-title">Bidang Keahlian</span>
                </a>
              </li>
              <li class="site-menu-item <?php echo e(in_array($linkActive, ['pengaturan-program']) ? 'active' : ''); ?>">
                <a class="animsition-link" href="<?php echo e(url('pengaturan-program')); ?>">
                  <span class="site-menu-title">Program Keahlian</span>
                </a>
              </li>
              <li class="site-menu-item <?php echo e(in_array($linkActive, ['pengaturan-kompetensi']) ? 'active' : ''); ?>">
                <a class="animsition-link" href="<?php echo e(url('pengaturan-kompetensi')); ?>">
                  <span class="site-menu-title">Kompetensi Keahlian</span>
                </a>
              </li>
              <li class="site-menu-item <?php echo e(in_array($linkActive, ['kelas']) ? 'active' : ''); ?>">
                <a class="animsition-link" href="<?php echo e(url('data/kelas')); ?>">
                  <span class="site-menu-title">Kelas</span>
                </a>
              </li>
              <li class="site-menu-item <?php echo e(in_array($linkActive, ['personal']) ? 'active' : ''); ?>">
                <a class="animsition-link" href="<?php echo e(url('data/personal')); ?>">
                  <span class="site-menu-title">Pegawai</span>
                </a>
              </li>
              <li class="site-menu-item <?php echo e(in_array($linkActive, ['siswa']) ? 'active' : ''); ?>">
                <a class="animsition-link" href="<?php echo e(url('data/siswa')); ?>">
                  <span class="site-menu-title">Siswa</span>
                </a>
              </li>
              <!--
              <li class="site-menu-item <?php echo e(in_array($linkActive, ['program']) ? 'active' : ''); ?>">
                <a class="animsition-link" href="<?php echo e(url('data/program')); ?>">
                  <span class="site-menu-title">Program</span>
                </a>
              </li>
              <li class="site-menu-item <?php echo e(in_array($linkActive, ['kompetensi']) ? 'active' : ''); ?>">
                <a class="animsition-link" href="<?php echo e(url('data/kompetensi')); ?>">
                  <span class="site-menu-title">Kompetensi</span>
                </a>
              </li>
              <li class="site-menu-item <?php echo e(in_array($linkActive, ['tapel']) ? 'active' : ''); ?>">
                <a class="animsition-link" href="<?php echo e(url('data/tapel')); ?>">
                  <span class="site-menu-title">Tahun Pelajaran</span>
                </a>
              </li> -->
            </ul>
          </li>
          <li class="site-menu-item has-sub <?php echo e(in_array($linkActive, ['pengaturan-sistem', 'pengaturan-pengguna']) ? 'active open' : ''); ?>">
            <a href="javascript:void(0)">
              <i class="site-menu-icon md-settings" aria-hidden="true"></i>
              <span class="site-menu-title">Pengaturan</span>
              <span class="site-menu-arrow"></span>
            </a>
            <ul class="site-menu-sub">
              <li class="site-menu-item <?php echo e(in_array($linkActive, ['pengaturan-sistem']) ? 'active' : ''); ?>">
                <a class="animsition-link" href="<?php echo e(url('pengaturan/sistem')); ?>">
                  <span class="site-menu-title">Sistem</span>
                </a>
              </li>
              <li class="site-menu-item <?php echo e(in_array($linkActive, ['pengaturan-pengguna']) ? 'active' : ''); ?>">
                <a class="animsition-link" href="<?php echo e(url('pengaturan/pengguna')); ?>">
                  <span class="site-menu-title">User</span>
                </a>
              </li>
            </ul>
          </li>
          <?php endif; ?>
          <?php if($idGrup == 1 or $idGrup == 2 or $idGrup == 6): ?>
          <li class="site-menu-item has-sub <?php echo e(in_array($linkActive, ['absensi-siswa', 'izin', 'scan-barcode-izin', 'pengaturan-kelas', 'kenaikan-kelas', 'kelulusan']) ? 'active open' : ''); ?>">
            <a href="javascript:void(0)">
              <i class="site-menu-icon md-assignment-account" aria-hidden="true"></i>
              <span class="site-menu-title">Akademik</span>
              <span class="site-menu-arrow"></span>
            </a>
            <ul class="site-menu-sub">
              <?php if($idGrup == 1 or $idGrup == 2): ?>
              <li class="site-menu-item <?php echo e(in_array($linkActive, ['absensi-siswa']) ? 'active' : ''); ?>">
                <a class="animsition-link" href="<?php echo e(url('akademik/absensi-siswa')); ?>">
                  <span class="site-menu-title">Absensi Siswa</span>
                </a>
              </li>
              <?php endif; ?>
              <?php if($idGrup == 1 or $idGrup == 6): ?>
              <li class="site-menu-item <?php echo e(in_array($linkActive, ['izin']) ? 'active' : ''); ?>">
                <a class="animsition-link" href="<?php echo e(url('akademik/izin')); ?>">
                  <span class="site-menu-title">Izin</span>
                </a>
              </li>
              <li class="site-menu-item <?php echo e(in_array($linkActive, ['scan-barcode-izin']) ? 'active' : ''); ?>">
                <a class="animsition-link" href="<?php echo e(url('akademik/scan-barcode-izin')); ?>">
                  <span class="site-menu-title">Scan QRCode Izin</span>
                </a>
              </li>
              <?php endif; ?>
              <?php if($idGrup == 1): ?>
              <li class="site-menu-item <?php echo e(in_array($linkActive, ['pengaturan-kelas']) ? 'active' : ''); ?>">
                <a class="animsition-link" href="<?php echo e(url('akademik/pengaturan-kelas')); ?>">
                  <span class="site-menu-title">Pengaturan Kelas</span>
                </a>
              </li>
              <li class="site-menu-item <?php echo e(in_array($linkActive, ['kenaikan-kelas']) ? 'active' : ''); ?>">
                <a class="animsition-link" href="<?php echo e(url('akademik/kenaikan-kelas')); ?>">
                  <span class="site-menu-title">Kenaikan Kelas</span>
                </a>
              </li>
              <li class="site-menu-item <?php echo e(in_array($linkActive, ['kelulusan']) ? 'active' : ''); ?>">
                <a class="animsition-link" href="<?php echo e(url('akademik/kelulusan')); ?>">
                  <span class="site-menu-title">Kelulusan</span>
                </a>
              </li>
              <?php endif; ?>
            </ul>
          </li>
          <?php endif; ?>
          <?php if($idGrup == 1 or $idGrup == 2 or $idGrup == 3): ?>
          <li class="site-menu-item has-sub <?php echo e(in_array($linkActive, ['laporan-absensi-kelas', 'laporan-absensi-siswa', 'laporan-rekap-izin']) ? 'active open' : ''); ?>">
            <a href="javascript:void(0)">
              <i class="site-menu-icon md-file" aria-hidden="true"></i>
              <span class="site-menu-title">Laporan</span>
              <span class="site-menu-arrow"></span>
            </a>
            <ul class="site-menu-sub">
              <?php if($idGrup == 1 or $idGrup == 2): ?>
              <li class="site-menu-item <?php echo e(in_array($linkActive, ['laporan-absensi-kelas']) ? 'active' : ''); ?>">
                <a class="animsition-link" href="<?php echo e(url('laporan/absensi-kelas')); ?>">
                  <span class="site-menu-title">Absensi Kelas</span>
                </a>
              </li>
              <?php endif; ?>
              <?php if($idGrup == 1 or $idGrup == 3): ?>
              <li class="site-menu-item <?php echo e(in_array($linkActive, ['laporan-absensi-siswa']) ? 'active' : ''); ?>">
                <a class="animsition-link" href="<?php echo e(url('laporan/absensi-siswa')); ?>">
                  <span class="site-menu-title">Absensi Siswa</span>
                </a>
              </li>
              <?php endif; ?>
              <?php if($idGrup == 1 or $idGrup == 2): ?>
              <li class="site-menu-item <?php echo e(in_array($linkActive, ['laporan-rekap-izin']) ? 'active' : ''); ?>">
                <a class="animsition-link" href="<?php echo e(url('laporan/rekap-izin')); ?>">
                  <span class="site-menu-title">Rekap Izin</span>
                </a>
              </li>
              <?php endif; ?>
            </ul>
          </li>
          <?php endif; ?>
        </ul>
      </div>
    </div>
  </div>
</div><?php /**PATH C:\xampp\htdocs\unsur\resources\views/common/menu.blade.php ENDPATH**/ ?>