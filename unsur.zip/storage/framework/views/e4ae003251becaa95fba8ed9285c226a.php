<!DOCTYPE html>
<html class="no-js css-menubar" lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
  <meta name="description" content="bootstrap material admin template">
  <meta name="author" content="">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
  <title>Sistem Informasi Izin Siswa | <?php echo e($titlePage); ?></title>
  <link rel="apple-touch-icon" href="<?php echo e(asset('assets/images/apple-touch-icon.png')); ?>">

  <!-- Stylesheets -->
  <link rel="stylesheet" href="<?php echo e(asset('global/css/bootstrap.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('global/css/bootstrap-extend.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/site.min.css')); ?>">
  <!-- Plugins -->
  <link rel="stylesheet" href="<?php echo e(asset('global/plugins/animsition/animsition.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('global/plugins/asscrollable/asScrollable.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('global/plugins/switchery/switchery.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('global/plugins/intro-js/introjs.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('global/plugins/slidepanel/slidePanel.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('global/plugins/flag-icon-css/flag-icon.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('global/plugins/waves/waves.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('global/plugins/sweetalert2/sweetalert2.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('global/plugins/bootstrap-datepicker/bootstrap-datepicker.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('global/plugins/summernote/summernote.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('global/plugins/select2/select2.css')); ?>">
  <!-- DataTable -->
  <link rel="stylesheet" href="<?php echo e(asset('global/plugins/datatables.net-bs4/dataTables.bootstrap4.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('global/plugins/datatables.net-fixedheader-bs4/dataTables.fixedheader.bootstrap4.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('global/plugins/datatables.net-fixedcolumns-bs4/dataTables.fixedcolumns.bootstrap4.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('global/plugins/datatables.net-rowgroup-bs4/dataTables.rowgroup.bootstrap4.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('global/plugins/datatables.net-scroller-bs4/dataTables.scroller.bootstrap4.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('global/plugins/datatables.net-select-bs4/dataTables.select.bootstrap4.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('global/plugins/datatables.net-responsive-bs4/dataTables.responsive.bootstrap4.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('global/plugins/datatables.net-buttons-bs4/dataTables.buttons.bootstrap4.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/examples/css/tables/datatable.css')); ?>">
  <!-- Fonts -->
  <link rel="stylesheet" href="<?php echo e(asset('global/fonts/font-awesome/css/font-awesome.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('global/fonts/material-design/material-design.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('global/fonts/brand-icons/brand-icons.min.css')); ?>">

  <!--[if lt IE 9]>
    <script src="<?php echo e(asset('global/plugins/html5shiv/html5shiv.min.js')); ?>"></script>
    <![endif]-->

  <!--[if lt IE 10]>
    <script src="<?php echo e(asset('global/plugins/media-match/media.match.min.js')); ?>"></script>
    <script src="<?php echo e(asset('global/plugins/respond/respond.min.js')); ?>"></script>
    <![endif]-->

  <!-- CSS Style -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">

  <!-- Scripts -->
  <script src="<?php echo e(asset('global/plugins/breakpoints/breakpoints.js')); ?>"></script>
</head>

<body class="animsition site-navbar-small"><?php /**PATH C:\xampp\htdocs\unsur\resources\views/common/header.blade.php ENDPATH**/ ?>