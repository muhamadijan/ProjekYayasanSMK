<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Yayasan Nurul Islam Affandiyyah</title>
    <link rel="icon" href="<?php echo e(asset('/assets/img/Logo_Yayasan.png')); ?>" type="image/x-icon">
    <!-- General CSS Files -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
    <!-- CSS Libraries -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <!-- Template CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/components.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('datatable/css/dataTables.css')); ?>">
    <link href="https://owlcarousel2.github.io/OwlCarousel2/assets/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet"/>
    <link href="https://owlcarousel2.github.io/OwlCarousel2/assets/css/animate.css" rel="stylesheet"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/color-calendar/dist/css/theme-basic.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/color-calendar/dist/css/theme-glass.css" />
    <script src="https://cdn.jsdelivr.net/npm/color-calendar/dist/bundle.min.js"></script>
    <script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
    <script src="https://owlcarousel2.github.io/OwlCarousel2/assets/owlcarousel/owl.carousel.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
    <script src="<?php echo e(asset('datatable/js/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('datatable/js/dataTables.js')); ?>"></script>
    <style>
    .kotak {
        color: #fff;
    }

    .table-style .today {
        background: #2A3F54;
        color: #ffffff;
    }

    .table-style th:nth-of-type(7),
    td:nth-of-type(7) {
        color: blue;
    }

    .table-style th:nth-of-type(1),
    td:nth-of-type(1) {
        color: red;
    }

    .table-style tr:first-child th {
        background-color: #F6F6F6;
        text-align: center;
        font-size: 15px;
    }

</style>
    <style>
        *{
            font-family: 'Poppins';
        }
    </style>
    <?php echo $__env->yieldContent('css'); ?>
</head>

<body>
    <div id="app">
        <div class="main-wrapper main-wrapper-1">
            <div class="navbar-bg"></div>
            <nav class="navbar navbar-expand-lg main-navbar">
                <form class="form-inline mr-auto">
                    <ul class="navbar-nav mr-3">
                        <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg"><i
                                    class="fas fa-bars"></i></a></li>
                    </ul>
                </form>
      

            </nav>
            <div class="main-sidebar sidebar-style-2">
                <aside id="sidebar-wrapper ">
                    <div class="sidebar-brand bg-primary">
                    <img alt="image" src="<?php echo e(asset('/assets/img/logo.png')); ?>" width="60px" height="60px"
         class="rounded-circle mr-1">
       
                        <!-- <a href=""><?php echo e(auth()->user()->name); ?></a> -->
                    </div>
                    <div class="sidebar-brand sidebar-brand-sm bg-primary">
                        <a href="">SIA v2.1</a>
                    </div>
                    <ul class="sidebar-menu ">
                        <li class="menu-header"> SIA v2.1</li>
                        <li class="nav-item">
                            <a class="nav-link collapsed" href="/dashboard">
                                <i class="fas fa-tachometer-alt text-info"></i>
                                <span>Dashboard</span>
                            </a>
                        </li>
                        
                        <li class="nav-item dropdown">
                            <a href="#" class="nav-link has-dropdown">
                                <i class="fas fa-university text-info"></i>
                                <span>Profil</span>
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="nav-link" href="<?php echo e(asset('/profil/sejarah')); ?>">Sejarah</a></li>
                                <li><a class="nav-link" href="<?php echo e(asset('/profil/visi-misi')); ?>">Visi dan Misi</a></li>
                                <li><a class="nav-link" href="<?php echo e(asset('/profil/struktur-organisasi')); ?>">Organigram</a></li>
                                <li><a class="nav-link" href="<?php echo e(asset('/profil/sarana')); ?>">Sarana Prasarana</a></li>
                                <li><a class="nav-link" href="<?php echo e(asset('/profil/kepala-yayasan')); ?>">Sambutan Yayasan</a></li>
                            </ul>
                        </li>
                        
                        <li class="nav-item dropdown">
                            <a href="#" class="nav-link has-dropdown">
                                <i class="fas fa-university text-info"></i>
                                <span>Program dan Layanan</span>
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="nav-link" href="<?php echo e(asset('/lembaga-pendidikan/pesantren')); ?>">Pondok Pesantren</a></li>
                                <li><a class="nav-link" href="<?php echo e(asset('/lembaga-pendidikan/mts')); ?>">Madrasah Tsanawiyah (MTS)</a></li>
                                <li><a class="nav-link" href="<?php echo e(asset('/lembaga-pendidikan/ma')); ?>">Madrasah Aliyah(MA)</a></li>
                                <li><a class="nav-link" href="<?php echo e(asset('/lembaga-pendidikan/smk')); ?>">Sekolah Menengah Kejuruan(SMK)</a></li>
                            </ul>
                        </li>
                        
                        <li class="nav-item dropdown">
                            <a href="#" class="nav-link has-dropdown">
                                <i class="fas fa-images text-info"></i>
                                <span>Galeri</span>
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="nav-link" href="<?php echo e(asset('/multimedia/galeri')); ?>">Foto</a></li>
                                <li><a class="nav-link" href="<?php echo e(asset('/profil/vidio')); ?>">Video</a></li>
                                <li><a class="nav-link"  href="<?php echo e(route('kontak.weblink.index')); ?>">Weblink</a></li>
                                <li><a class="nav-link"  href="<?php echo e(route('profil.logo.index')); ?>">Logo</a></li>
                                <li><a class="nav-link"  href="<?php echo e(route('profil.navbar.index')); ?>">Navbar</a></li>
                            </ul>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link collapsed" href="<?php echo e(asset('/profil/berita')); ?>">
                                <i class="fas fa-edit text-info"></i>
                                <span>Berita</span>
                            </a>
                        </li>
                        
                        
                        <li class="nav-item">
                            <a class="nav-link collapsed" href="<?php echo e(asset('/kontak/kontak-yayasan')); ?>">
                                <i class="fas fa-phone-alt text-info"></i>
                                <span>Kontak</span>
                            </a>
                        </li>
                        
                        <li class="nav-item dropdown">
                            <a href="#" class="nav-link has-dropdown">
                                <i class="fas fa-user text-info"></i>
                                <span>Akun</span>
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="nav-link" href="<?php echo e(asset('/akun/admin')); ?>">Ubah Password</a></li>
                            </ul>
                        </li>
                        
                            
                            <li class="dropdown">
    <a href="<?php echo e(route('logout')); ?>" style="cursor: pointer" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" class="dropdown-item has-icon text-danger">
        <i class="fas fa-sign-out-alt"></i> Logout
    </a>
    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
        <?php echo csrf_field(); ?>
    </form>
</li>
    

                          
                    </ul>
                </aside>
            </div>

            <!-- Main Content -->
            <?php echo $__env->yieldContent('content'); ?>

            <footer  class="main-footer ">
                <div class="footer-left">
                     &copy; 2023 <div class="bullet"></div> SIA v2.1 <div class="bullet"></div>Farijan
                </div>
                <div class="footer-right">

                </div>
            </footer>
        </div>
    </div>

    <!-- General JS Scripts -->
    <script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.nicescroll/3.7.6/jquery.nicescroll.min.js"></script>
    <script src="<?php echo e(asset('assets/js/stisla.js')); ?>"></script>

    <!-- JS Libraies -->

    <!-- Page Specific JS File -->

    <!-- Template JS File -->
    <script src="<?php echo e(asset('assets/js/scripts.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
    <?php echo $__env->yieldContent('js'); ?>

    <script>
        //active select2


        //flash message
        <?php if(session()-> has('success')): ?>
        swal({
            type: "success",
            icon: "success",
            title: "BERHASIL!",
            text: "<?php echo e(session('success')); ?>",
            timer: 1500,
            showConfirmButton: false,
            showCancelButton: false,
            buttons: false,
        });
        <?php elseif(session()-> has('error')): ?>
        swal({
            type: "error",
            icon: "error",
            title: "GAGAL!",
            text: "<?php echo e(session('error')); ?>",
            timer: 1500,
            showConfirmButton: false,
            showCancelButton: false,
            buttons: false,
        });
        <?php endif; ?>
    </script>
    <script>
    document.querySelector('a[onclick]').addEventListener('click', function(e) {
        e.preventDefault();
        if (confirm('Apakah Anda yakin ingin keluar?')) {
            document.getElementById('logout-form').submit();
        }
    });
</script>

</body>
</html><?php /**PATH C:\xampp\htdocs\unsur\resources\views/layouts/admin.blade.php ENDPATH**/ ?>