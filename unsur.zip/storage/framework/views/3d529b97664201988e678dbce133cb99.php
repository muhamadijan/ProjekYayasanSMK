<?php $__env->startSection('content'); ?>
<div class="main-content">
    <section class="section">
        <div class="section-header">
            <h1>Detail</h1>
        </div>
        <div class="section-body">
           
            <div class="card">
                <div class="card-header">
                    <h4><i class="fas fa-chalkboard-teacher"></i> Detail</h4>
                </div>
                <div class="card-body">
                    <h5 class="text-center"><?php echo e($ma->judul); ?></h5>
                    <center>
                        <img src="<?php echo e(asset('/image/'.$ma->gambar)); ?>" alt="" class="img img-thumbnail border-0 rounded-lg" width="300">
                    </center>
                    <p><?php echo $ma->isi; ?></p>
                    <p><?php echo $ma->link_web; ?></p>
                </div>
            </div>
        </div>
</div>
    </section>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\unsur\resources\views/lembaga-pendidikan/ma/detail.blade.php ENDPATH**/ ?>