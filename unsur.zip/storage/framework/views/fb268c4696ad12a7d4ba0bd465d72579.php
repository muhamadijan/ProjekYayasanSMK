<nav class="site-navbar navbar navbar-default navbar-fixed-top navbar-mega" role="navigation">
  <div class="navbar-header">
    <button type="button" class="navbar-toggler hamburger hamburger-close navbar-toggler-left hided" data-toggle="menubar">
      <span class="sr-only">Toggle navigation</span>
      <span class="hamburger-bar"></span>
    </button>
    <button type="button" class="navbar-toggler collapsed" data-target="#site-navbar-collapse" data-toggle="collapse">
      <i class="icon md-more" aria-hidden="true"></i>
    </button>
    <div class="navbar-brand navbar-brand-center site-gridmenu-toggle" data-toggle="menubar">
      <img class="navbar-brand-logo" src="">
      <span class="navbar-brand-text hidden-xs-down">Sistem Izin Siswa</span>
    </div>
  </div>

  <div class="navbar-container container-fluid">
    <!-- Navbar Collapse -->
    <div class="collapse navbar-collapse navbar-collapse-toolbar" id="site-navbar-collapse">
      <!-- Navbar Toolbar -->
      <ul class="nav navbar-toolbar">
        <li class="nav-item hidden-float" id="toggleMenubar">
          <a class="nav-link" data-toggle="menubar" href="#" role="button">
            <i class="icon hamburger hamburger-arrow-left">
              <span class="sr-only">Toggle menubar</span>
              <span class="hamburger-bar"></span>
            </i>
          </a>
        </li>
      </ul>
      <!-- End Navbar Toolbar -->

      <!-- Navbar Toolbar Right -->
      <ul class="nav navbar-toolbar navbar-right navbar-toolbar-right">
        <li class="nav-item dropdown">
          <a class="nav-link navbar-avatar" data-toggle="dropdown" href="#" aria-expanded="false" data-animation="scale-up" role="button">
            <span><?php echo e(Auth::user()->akun); ?></span>
            <span class="avatar avatar-online">
              <img src="" alt="...">
              <i></i>
            </span>
          </a>
          <div class="dropdown-menu" role="menu">
            <a class="dropdown-item" href="javascript:void(0)" onclick="ubahPassword()" role="menuitem"><i class="icon md-settings" aria-hidden="true"></i> Ubah Password</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" role="menuitem" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
              <i class="icon md-power" aria-hidden="true"></i> Logout
            </a>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
              <?php echo csrf_field(); ?>
            </form>
          </div>
        </li>
      </ul>
      <!-- End Navbar Toolbar Right -->
    </div>
    <!-- End Navbar Collapse -->
  </div>
</nav>

<!-- Modal Sidebar-->
<div class="modal fade" id="openform-ubah-password" aria-hidden="true" aria-labelledby="openform-ubah-password" role="dialog" tabindex="-1" data-backdrop="static">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
        <h4 class="modal-title">Form Ubah Passowrd</h4>
      </div>
      <form class="form-ubah-password">
        <div class="modal-body">
          <div class="col-md-12">
            <div class="form-group row">
              <label class="col-md-3 form-control-label">Password Lama</label>
              <div class="col-md-9">
                <input type="password" class="form-control" name="password_lama" required autocomplete="off" />
              </div>
            </div>
            <div class="form-group row">
              <label class="col-md-3 form-control-label">Passwoord Baru</label>
              <div class="col-md-9">
                <input type="password" class="form-control" name="password_baru" required autocomplete="off" />
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-success btn-simpan">Simpan</button>
          <button type="button" class="btn btn-success btn-loading" disabled><i class="fa fa-spinner fa-spin"></i> Loading</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
        </div>
      </form>
    </div>
  </div>
</div>
<!-- End Modal --><?php /**PATH C:\xampp\htdocs\unsur\resources\views/common/navbar.blade.php ENDPATH**/ ?>