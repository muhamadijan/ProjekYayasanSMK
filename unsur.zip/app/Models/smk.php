<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class smk extends Model
{
    protected $table = 'smk';
	protected $guarded = ['id'];
	protected $primaryKey = 'id';
}
