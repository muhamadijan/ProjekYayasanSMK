<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class vidio extends Model
{
    protected $table = 'vidio';
	protected $guarded = ['id'];
	protected $primaryKey = 'id';
}
