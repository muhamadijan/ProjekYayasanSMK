<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ma extends Model
{
    protected $table = 'ma';
	protected $guarded = ['id'];
	protected $primaryKey = 'id';
}
